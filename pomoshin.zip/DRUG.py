import os
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import threading
import time
from datetime import datetime

class DarkProjectAnalyzer:
    def __init__(self, root):
        self.root = root
        self.root.title("Dark Project Analyzer")
        self.root.geometry("1000x800")
        
        # Устанавливаем темную тему
        self.setup_dark_theme()
        
        self.setup_ui()
        
    def setup_dark_theme(self):
        # Цветовая схема в темно-фиолетово-черных тонах
        self.colors = {
            'bg_dark': '#0a0a14',
            'bg_darker': '#05050a',
            'bg_panel': '#1a1a2e',
            'bg_widget': '#2d2d44',
            'purple_dark': '#4a2a7a',
            'purple_medium': '#6b3fa0',
            'purple_light': '#8a5cc5',
            'purple_glow': '#a67fd6',
            'text_light': '#e6e6fa',
            'text_muted': '#b0a8d0',
            'accent': '#ff6b9d',
            'success': '#2ecc71',
            'warning': '#f39c12',
            'error': '#e74c3c',
            'gguf_color': '#00ff9d'  # Специальный цвет для .gguf файлов
        }
        
        self.root.configure(bg=self.colors['bg_dark'])
    
    def setup_ui(self):
        # Заголовок
        header_frame = tk.Frame(self.root, bg=self.colors['bg_darker'])
        header_frame.pack(fill=tk.X, padx=20, pady=(20, 10))
        
        title_label = tk.Label(
            header_frame,
            text="🌙 DARK PROJECT ANALYZER v3.0",
            font=("Arial", 24, "bold"),
            fg=self.colors['purple_light'],
            bg=self.colors['bg_darker']
        )
        title_label.pack()
        
        subtitle_label = tk.Label(
            header_frame,
            text="Анализатор структуры проектов с поддержкой .gguf файлов",
            font=("Arial", 10),
            fg=self.colors['text_muted'],
            bg=self.colors['bg_darker']
        )
        subtitle_label.pack()
        
        # Специальная метка для .gguf файлов
        gguf_label = tk.Label(
            header_frame,
            text="💎 Обнаружение .gguf файлов (бинарные файлы не читаются)",
            font=("Arial", 9, "italic"),
            fg=self.colors['gguf_color'],
            bg=self.colors['bg_darker']
        )
        gguf_label.pack(pady=(5, 0))
        
        # Основной контейнер
        main_container = tk.Frame(self.root, bg=self.colors['bg_dark'])
        main_container.pack(fill=tk.BOTH, expand=True, padx=20, pady=10)
        
        # Панель управления
        control_panel = tk.Frame(
            main_container,
            bg=self.colors['bg_panel'],
            relief=tk.FLAT,
            bd=2,
            highlightbackground=self.colors['purple_dark'],
            highlightthickness=1
        )
        control_panel.pack(fill=tk.X, pady=(0, 10))
        
        # Кнопки управления
        button_frame = tk.Frame(control_panel, bg=self.colors['bg_panel'])
        button_frame.pack(pady=15, padx=15)
        
        # Стилизованные кнопки
        button_style = {
            'font': ("Arial", 10, "bold"),
            'padx': 20,
            'pady': 10,
            'bd': 0,
            'cursor': 'hand2'
        }
        
        self.select_btn = tk.Button(
            button_frame,
            text="📁 ВЫБРАТЬ ПАПКУ",
            command=self.select_folder,
            bg=self.colors['purple_dark'],
            fg=self.colors['text_light'],
            activebackground=self.colors['purple_medium'],
            activeforeground=self.colors['text_light'],
            **button_style
        )
        self.select_btn.pack(side=tk.LEFT, padx=5)
        
        self.analyze_btn = tk.Button(
            button_frame,
            text="🔍 АНАЛИЗИРОВАТЬ",
            command=self.analyze_project,
            bg=self.colors['purple_medium'],
            fg=self.colors['text_light'],
            activebackground=self.colors['purple_light'],
            activeforeground=self.colors['text_light'],
            state=tk.DISABLED,
            **button_style
        )
        self.analyze_btn.pack(side=tk.LEFT, padx=5)
        
        self.save_btn = tk.Button(
            button_frame,
            text="💾 СОХРАНИТЬ",
            command=self.save_to_file,
            bg=self.colors['bg_widget'],
            fg=self.colors['text_light'],
            activebackground=self.colors['purple_dark'],
            activeforeground=self.colors['text_light'],
            state=tk.DISABLED,
            **button_style
        )
        self.save_btn.pack(side=tk.LEFT, padx=5)
        
        # Счетчик .gguf файлов
        self.gguf_counter_frame = tk.Frame(control_panel, bg=self.colors['bg_panel'])
        self.gguf_counter_frame.pack(pady=(0, 10), padx=15)
        
        self.gguf_counter_label = tk.Label(
            self.gguf_counter_frame,
            text="💎 Найденные .gguf файлы: 0",
            font=("Arial", 9),
            bg=self.colors['bg_panel'],
            fg=self.colors['gguf_color']
        )
        self.gguf_counter_label.pack()
        
        # Информация о выбранной папке
        folder_info_frame = tk.Frame(control_panel, bg=self.colors['bg_panel'])
        folder_info_frame.pack(fill=tk.X, padx=15, pady=(0, 15))
        
        folder_icon = tk.Label(
            folder_info_frame,
            text="📂",
            font=("Arial", 12),
            bg=self.colors['bg_panel'],
            fg=self.colors['purple_light']
        )
        folder_icon.pack(side=tk.LEFT)
        
        self.folder_label = tk.Label(
            folder_info_frame,
            text="Папка проекта не выбрана",
            font=("Arial", 9),
            bg=self.colors['bg_panel'],
            fg=self.colors['text_muted']
        )
        self.folder_label.pack(side=tk.LEFT, padx=10)
        
        # Прогресс бар
        self.progress_container = tk.Frame(main_container, bg=self.colors['bg_dark'])
        self.progress_container.pack(fill=tk.X, pady=(0, 10))
        
        self.progress_label = tk.Label(
            self.progress_container,
            text="",
            font=("Arial", 9),
            bg=self.colors['bg_dark'],
            fg=self.colors['text_muted']
        )
        self.progress_label.pack(anchor=tk.W)
        
        # Кастомный прогресс бар
        self.progress_canvas = tk.Canvas(
            self.progress_container,
            height=10,
            bg=self.colors['bg_widget'],
            highlightthickness=0
        )
        self.progress_canvas.pack(fill=tk.X, pady=(5, 0))
        
        self.progress_bar = self.progress_canvas.create_rectangle(
            0, 0, 0, 10,
            fill=self.colors['purple_light'],
            outline=""
        )
        
        self.progress_text = self.progress_canvas.create_text(
            5, 5,
            text="0%",
            anchor=tk.W,
            fill=self.colors['text_light'],
            font=("Arial", 8)
        )
        
        # Текстовое поле для вывода
        text_frame = tk.Frame(
            main_container,
            bg=self.colors['bg_panel'],
            relief=tk.FLAT,
            bd=2,
            highlightbackground=self.colors['purple_dark'],
            highlightthickness=1
        )
        text_frame.pack(fill=tk.BOTH, expand=True)
        
        # Заголовок текстового поля
        text_header = tk.Frame(text_frame, bg=self.colors['bg_panel'])
        text_header.pack(fill=tk.X, padx=10, pady=(10, 0))
        
        tk.Label(
            text_header,
            text="РЕЗУЛЬТАТЫ АНАЛИЗА",
            font=("Arial", 10, "bold"),
            bg=self.colors['bg_panel'],
            fg=self.colors['purple_light']
        ).pack(side=tk.LEFT)
        
        # Количество символов
        self.char_count_label = tk.Label(
            text_header,
            text="Символов: 0 | .gguf файлов: 0",
            font=("Arial", 8),
            bg=self.colors['bg_panel'],
            fg=self.colors['text_muted']
        )
        self.char_count_label.pack(side=tk.RIGHT)
        
        # Само текстовое поле
        self.text_area = scrolledtext.ScrolledText(
            text_frame,
            wrap=tk.WORD,
            font=("Consolas", 9),
            bg=self.colors['bg_widget'],
            fg=self.colors['text_light'],
            insertbackground=self.colors['purple_light'],
            selectbackground=self.colors['purple_dark'],
            selectforeground=self.colors['text_light'],
            relief=tk.FLAT,
            bd=0,
            padx=10,
            pady=10
        )
        self.text_area.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # Статус бар
        status_frame = tk.Frame(
            self.root,
            bg=self.colors['bg_darker'],
            height=30
        )
        status_frame.pack(side=tk.BOTTOM, fill=tk.X)
        status_frame.pack_propagate(False)
        
        self.status_bar = tk.Label(
            status_frame,
            text="🟢 Готов к работе",
            bd=0,
            relief=tk.FLAT,
            anchor=tk.W,
            bg=self.colors['bg_darker'],
            fg=self.colors['text_muted'],
            font=("Arial", 9)
        )
        self.status_bar.pack(side=tk.LEFT, padx=15)
        
        # Иконка состояния
        self.status_icon = tk.Label(
            status_frame,
            text="●",
            font=("Arial", 12),
            bg=self.colors['bg_darker'],
            fg=self.colors['success'],
            padx=10
        )
        self.status_icon.pack(side=tk.RIGHT)
        
        self.project_path = None
        self.analysis_result = ""
        self.current_progress = 0
        self.total_files = 0
        self.processed_files = 0
        self.gguf_files_count = 0
        self.gguf_files_list = []
        self.skipped_files = []
        
    def select_folder(self):
        folder = filedialog.askdirectory(title="Выберите папку проекта")
        if folder:
            self.project_path = folder
            folder_name = os.path.basename(folder)
            self.folder_label.config(
                text=f"{folder_name[:30]}...{folder_name[-20:]}" if len(folder_name) > 50 else folder_name,
                fg=self.colors['purple_light']
            )
            self.analyze_btn.config(state=tk.NORMAL)
            self.save_btn.config(state=tk.DISABLED)
            self.text_area.delete(1.0, tk.END)
            self.update_status(f"Выбрана папка: {folder_name}", self.colors['success'])
            self.reset_progress()
            self.reset_gguf_counter()
    
    def analyze_project(self):
        if not self.project_path:
            messagebox.showerror("Ошибка", "Сначала выберите папку проекта!")
            return
            
        self.text_area.delete(1.0, tk.END)
        self.update_status("Начинаю анализ проекта...", self.colors['warning'])
        self.analyze_btn.config(state=tk.DISABLED)
        self.save_btn.config(state=tk.DISABLED)
        self.reset_progress()
        self.reset_gguf_counter()
        
        # Запускаем анализ в отдельном потоке
        thread = threading.Thread(target=self.perform_analysis)
        thread.daemon = True
        thread.start()
    
    def perform_analysis(self):
        try:
            self.analysis_result = self.scan_project(self.project_path)
            
            # Обновляем GUI из основного потока
            self.root.after(0, self.update_text_area)
            self.root.after(0, self.analysis_complete)
            
        except Exception as e:
            self.root.after(0, lambda: self.show_error("Ошибка анализа", str(e)))
            self.root.after(0, self.analysis_failed)
    
    def is_binary_file(self, filepath):
        """Определяет, является ли файл бинарным"""
        try:
            with open(filepath, 'rb') as f:
                chunk = f.read(1024)
                # Если в первых 1024 байтах есть нулевые байты - вероятно бинарный
                if b'\x00' in chunk:
                    return True
                # Проверяем на наличие не-ASCII символов
                try:
                    chunk.decode('utf-8')
                except UnicodeDecodeError:
                    return True
        except:
            return True
        return False
    
    def scan_project(self, folder_path):
        result = []
        result.append("═" * 80)
        result.append(f"🌙 DARK PROJECT ANALYSIS v3.0")
        result.append(f"📁 ПРОЕКТ: {os.path.basename(folder_path)}")
        result.append(f"📍 ПУТЬ: {folder_path}")
        result.append(f"🕒 ВРЕМЯ: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        result.append("═" * 80 + "\n")
        
        # Игнорируемые папки и файлы
        ignore_dirs = {'.git', '__pycache__', '.venv', 'venv', 'env', '.idea', '.vscode', 'node_modules'}
        ignore_ext = {'.pyc', '.pyo', '.pyd', '.so', '.dll', '.exe', '.jpg', '.png', '.gif', '.pdf', '.zip', 
                     '.mp4', '.mp3', '.avi', '.mkv', '.wav', '.ogg', '.bin', '.dat'}
        
        # Бинарные расширения, которые точно не будем читать
        binary_extensions = {'.gguf', '.ggml', '.bin', '.dat', '.pth', '.h5', '.hdf5', '.npz', 
                           '.model', '.weights', '.pt', '.pkl', '.pickle'}
        
        # Сначала считаем общее количество файлов для прогресса
        self.total_files = 0
        for root, dirs, files in os.walk(folder_path):
            dirs[:] = [d for d in dirs if d not in ignore_dirs]
            self.total_files += len([f for f in files if not any(f.endswith(ext) for ext in ignore_ext)])
        
        self.root.after(0, lambda: self.update_progress(5, f"Найдено {self.total_files} файлов..."))
        
        # Получаем все файлы
        all_files = []
        self.gguf_files_list = []
        self.skipped_files = []
        
        for root, dirs, files in os.walk(folder_path):
            dirs[:] = [d for d in dirs if d not in ignore_dirs]
            
            for file in files:
                if not any(file.endswith(ext) for ext in ignore_ext):
                    rel_path = os.path.relpath(os.path.join(root, file), folder_path)
                    full_path = os.path.join(root, file)
                    all_files.append((rel_path, full_path))
                    
                    # Проверяем на .gguf файлы
                    if file.endswith('.gguf'):
                        self.gguf_files_list.append(full_path)
                        self.gguf_files_count += 1
                        self.root.after(0, self.update_gguf_counter)
        
        all_files.sort(key=lambda x: x[0])
        
        # Структура каталогов
        result.append("\n📂 СТРУКТУРА КАТАЛОГОВ:")
        result.append("─" * 40)
        
        self.root.after(0, lambda: self.update_progress(15, "Анализ структуры..."))
        
        dir_structure = {}
        for rel_path, _ in all_files:
            dir_name = os.path.dirname(rel_path)
            if dir_name not in dir_structure:
                dir_structure[dir_name] = []
            dir_structure[dir_name].append(os.path.basename(rel_path))
        
        for dir_name in sorted(dir_structure.keys()):
            if dir_name:
                result.append(f"│   📁 {dir_name}/")
            for file_name in sorted(dir_structure[dir_name]):
                indent = "│       " if dir_name else "│   "
                file_icon = "💎" if file_name.endswith('.gguf') else "📄"
                color_start = "💎 " if file_name.endswith('.gguf') else ""
                color_end = "" if not file_name.endswith('.gguf') else " 💎"
                result.append(f"{indent}{file_icon} {color_start}{file_name}{color_end}")
        
        # СЕКЦИЯ .GGUF ФАЙЛОВ
        if self.gguf_files_count > 0:
            result.append("\n\n" + "★" * 60)
            result.append("💎 СПЕЦИАЛЬНЫЙ РАЗДЕЛ: .GGUF ФАЙЛЫ (БИНАРНЫЕ)")
            result.append("★" * 60 + "\n")
            
            result.append(f"Всего найдено .gguf файлов: {self.gguf_files_count}\n")
            result.append("⚠️  Внимание: .gguf файлы являются бинарными и не читаются как текст\n")
            
            for i, gguf_path in enumerate(self.gguf_files_list, 1):
                rel_path = os.path.relpath(gguf_path, folder_path)
                file_size = os.path.getsize(gguf_path)
                size_mb = file_size / (1024 * 1024)
                
                result.append(f"{i}. 📍 ФАЙЛ: {rel_path}")
                result.append(f"   🔗 ПОЛНЫЙ ПУТЬ: {gguf_path}")
                result.append(f"   📏 РАЗМЕР: {file_size:,} байт ({size_mb:.2f} MB)".replace(',', ' '))
                result.append(f"   📅 СОЗДАН: {datetime.fromtimestamp(os.path.getctime(gguf_path)).strftime('%Y-%m-%d %H:%M:%S')}")
                result.append(f"   📅 ИЗМЕНЕН: {datetime.fromtimestamp(os.path.getmtime(gguf_path)).strftime('%Y-%m-%d %H:%M:%S')}")
                result.append("   " + "─" * 50)
        
        # Содержимое обычных файлов
        result.append("\n\n" + "═" * 80)
        result.append("📄 СОДЕРЖАНИЕ ТЕКСТОВЫХ ФАЙЛОВ:")
        result.append("═" * 80 + "\n")
        
        self.processed_files = 0
        text_files = [f for f in all_files if not f[0].endswith('.gguf')]
        
        for rel_path, full_path in text_files:
            try:
                self.processed_files += 1
                progress = 20 + (self.processed_files / len(text_files)) * 75
                self.root.after(0, lambda p=progress, f=os.path.basename(rel_path): self.update_progress(
                    p, 
                    f"Обработка файла {self.processed_files}/{len(text_files)}: {f}"
                ))
                
                # Проверяем, не бинарный ли файл
                if any(full_path.endswith(ext) for ext in binary_extensions):
                    self.skipped_files.append((rel_path, "Бинарное расширение"))
                    result.append(f"\n{'─' * 60}")
                    result.append(f"⚠️  ФАЙЛ: {rel_path}")
                    result.append("❌ ПРОПУЩЕН: Файл имеет бинарное расширение")
                    result.append(f"{'─' * 60}\n")
                    continue
                
                if self.is_binary_file(full_path):
                    self.skipped_files.append((rel_path, "Определен как бинарный"))
                    result.append(f"\n{'─' * 60}")
                    result.append(f"⚠️  ФАЙЛ: {rel_path}")
                    result.append("❌ ПРОПУЩЕН: Файл определен как бинарный")
                    result.append(f"{'─' * 60}\n")
                    continue
                
                with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                cleaned_content = ' '.join(content.split())
                
                result.append(f"\n{'─' * 60}")
                result.append(f"📄 ФАЙЛ: {rel_path}")
                result.append(f"📏 РАЗМЕР: {len(content):,} символов".replace(',', ' '))
                result.append(f"📊 СТРОК: {len(content.splitlines())}")
                result.append(f"📝 СОДЕРЖАНИЕ В ОДНУ СТРОКУ:")
                result.append("─" * 40)
                
                if len(cleaned_content) > 5000:
                    cleaned_content = cleaned_content[:5000] + "... [ОБРЕЗАНО ДО 5000 СИМВОЛОВ]"
                
                result.append(cleaned_content)
                result.append(f"{'─' * 60}\n")
                
            except UnicodeDecodeError:
                self.skipped_files.append((rel_path, "Ошибка декодирования UTF-8"))
                result.append(f"\n{'─' * 60}")
                result.append(f"⚠️  ФАЙЛ: {rel_path}")
                result.append("❌ ПРОПУЩЕН: Ошибка декодирования (возможно бинарный файл)")
                result.append(f"{'─' * 60}\n")
                continue
                
            except PermissionError:
                self.skipped_files.append((rel_path, "Отказано в доступе"))
                result.append(f"\n{'─' * 60}")
                result.append(f"⚠️  ФАЙЛ: {rel_path}")
                result.append("❌ ПРОПУЩЕН: Отказано в доступе к файлу")
                result.append(f"{'─' * 60}\n")
                continue
                
            except Exception as e:
                self.skipped_files.append((rel_path, str(e)))
                result.append(f"\n{'─' * 60}")
                result.append(f"⚠️  ФАЙЛ: {rel_path}")
                result.append(f"❌ ПРОПУЩЕН: {str(e)}")
                result.append(f"{'─' * 60}\n")
                continue
        
        # Итоговая статистика
        result.append("\n" + "★" * 60)
        result.append("📊 ИТОГОВАЯ СТАТИСТИКА:")
        result.append("★" * 60)
        result.append(f"📁 Всего файлов в проекте: {self.total_files}")
        result.append(f"💎 .gguf файлов найдено: {self.gguf_files_count}")
        result.append(f"📄 Текстовых файлов обработано: {len(text_files) - len(self.skipped_files)}")
        result.append(f"⚠️  Файлов пропущено: {len(self.skipped_files)}")
        
        if self.skipped_files:
            result.append("\n📋 ПРОПУЩЕННЫЕ ФАЙЛЫ:")
            for i, (file_path, reason) in enumerate(self.skipped_files[:10], 1):
                result.append(f"  {i}. {file_path} - {reason}")
            if len(self.skipped_files) > 10:
                result.append(f"  ... и еще {len(self.skipped_files) - 10} файлов")
        
        result.append(f"\n🕒 Время завершения анализа: {datetime.now().strftime('%H:%M:%S')}")
        
        return "\n".join(result)
    
    def update_text_area(self):
        self.text_area.delete(1.0, tk.END)
        self.text_area.insert(1.0, self.analysis_result)
        
        # Подсвечиваем .gguf файлы в текстовом поле
        self.highlight_gguf_content()
        
        # Обновляем счетчики
        char_count = len(self.analysis_result)
        self.char_count_label.config(
            text=f"Символов: {char_count:,} | .gguf файлов: {self.gguf_files_count} | Пропущено: {len(self.skipped_files)}".replace(',', ' ')
        )
    
    def highlight_gguf_content(self):
        """Подсвечивает упоминания .gguf файлов в текстовом поле"""
        self.text_area.tag_configure("gguf", foreground=self.colors['gguf_color'])
        
        content = self.text_area.get(1.0, tk.END)
        start_idx = "1.0"
        
        while True:
            start_idx = self.text_area.search(".gguf", start_idx, tk.END)
            if not start_idx:
                break
            
            end_idx = f"{start_idx}+5c"  # 5 символов для ".gguf"
            self.text_area.tag_add("gguf", start_idx, end_idx)
            start_idx = end_idx
    
    def analysis_complete(self):
        self.save_btn.config(state=tk.NORMAL)
        self.analyze_btn.config(state=tk.NORMAL)
        self.update_progress(100, "Анализ завершен!")
        
        if self.gguf_files_count > 0:
            self.update_status(f"✅ Анализ завершен! Найдено {self.gguf_files_count} .gguf файлов", self.colors['gguf_color'])
        else:
            self.update_status("✅ Анализ успешно завершен", self.colors['success'])
    
    def analysis_failed(self):
        self.analyze_btn.config(state=tk.NORMAL)
        self.update_status("❌ Ошибка анализа", self.colors['error'])
    
    def save_to_file(self):
        if not self.analysis_result:
            self.show_warning("Сначала проанализируйте проект!")
            return
            
        file_path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialfile=f"project_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
            title="Сохранить результаты анализа"
        )
        
        if file_path:
            try:
                self.update_status("Сохранение файла...", self.colors['warning'])
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(self.analysis_result)
                
                # Если есть .gguf файлы, сохраняем их отдельным списком
                if self.gguf_files_count > 0:
                    gguf_list_path = file_path.replace('.txt', '_gguf_locations.txt')
                    with open(gguf_list_path, 'w', encoding='utf-8') as f:
                        f.write("СПИСОК .GGUF ФАЙЛОВ:\n")
                        f.write("=" * 50 + "\n\n")
                        for i, path in enumerate(self.gguf_files_list, 1):
                            file_size = os.path.getsize(path)
                            size_mb = file_size / (1024 * 1024)
                            f.write(f"{i}. {path}\n")
                            f.write(f"   Размер: {file_size:,} байт ({size_mb:.2f} MB)\n\n")
                    
                    self.show_info(
                        "Файлы сохранены", 
                        f"Основные результаты:\n{file_path}\n\n"
                        f"Список .gguf файлов:\n{gguf_list_path}"
                    )
                else:
                    self.show_info("Файл сохранен", f"Результаты сохранены в:\n{file_path}")
                    
                self.update_status(f"✅ Файл сохранен: {os.path.basename(file_path)}", self.colors['success'])
            except Exception as e:
                self.show_error("Ошибка сохранения", str(e))
    
    def update_status(self, message, color=None):
        self.status_bar.config(text=message)
        if color:
            self.status_icon.config(fg=color)
    
    def update_progress(self, percent, message=""):
        self.current_progress = percent
        canvas_width = self.progress_canvas.winfo_width()
        if canvas_width > 0:
            progress_width = (canvas_width * percent) / 100
            self.progress_canvas.coords(self.progress_bar, 0, 0, progress_width, 10)
            self.progress_canvas.coords(
                self.progress_text, 
                progress_width - 30 if percent > 10 else 5, 
                5
            )
            self.progress_canvas.itemconfig(self.progress_text, text=f"{int(percent)}%")
        
        if message:
            self.progress_label.config(text=message)
    
    def update_gguf_counter(self):
        self.gguf_counter_label.config(
            text=f"💎 Найденные .gguf файлы: {self.gguf_files_count}",
            fg=self.colors['gguf_color']
        )
    
    def reset_progress(self):
        self.current_progress = 0
        self.progress_canvas.coords(self.progress_bar, 0, 0, 0, 10)
        self.progress_canvas.coords(self.progress_text, 5, 5)
        self.progress_canvas.itemconfig(self.progress_text, text="0%")
        self.progress_label.config(text="")
    
    def reset_gguf_counter(self):
        self.gguf_files_count = 0
        self.gguf_files_list = []
        self.gguf_counter_label.config(
            text="💎 Найденные .gguf файлы: 0",
            fg=self.colors['gguf_color']
        )
    
    def show_info(self, title, message):
        messagebox.showinfo(title, message)
    
    def show_warning(self, message):
        messagebox.showwarning("Внимание", message)
    
    def show_error(self, title, message):
        messagebox.showerror(title, message)

def main():
    root = tk.Tk()
    app = DarkProjectAnalyzer(root)
    
    # Центрирование окна
    root.update_idletasks()
    width = root.winfo_width()
    height = root.winfo_height()
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry(f'{width}x{height}+{x}+{y}')
    
    root.mainloop()

if __name__ == "__main__":
    main()